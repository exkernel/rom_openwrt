module("luci.controller.sysuh3c", package.seeall)

function index()
    entry({"admin", "sysuh3c"}, cbi("sysuh3c"), "-Inode-", 80).dependent=false
end
