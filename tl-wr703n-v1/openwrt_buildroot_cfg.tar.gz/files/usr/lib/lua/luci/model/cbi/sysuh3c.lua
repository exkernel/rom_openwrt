local userconf = "sysuh3c"
local uci = luci.model.uci.cursor()

if luci.sys.call("pidof sysuh3c >/dev/null") == 0 then
	m = Map(userconf, "SYSU-Inode", "# luci-app-sysuh3c By:EricChan/chenhw2(2011~2015@SIST.SYSU)<br\/># sysuh3c By:zonyitoo(2010~2014@SIST.SYSU)<br\/>==============================================<br\/>sysuh3c is running")
else
	m = Map(userconf, "SYSU-Inode", "# luci-app-sysuh3c By:EricChan/chenhw2(2011~2015@SIST.SYSU)<br\/># sysuh3c By:zonyitoo(2010~2014@SIST.SYSU)<br\/>==============================================<br\/>sysuh3c is not running")
end
m.reset = false

s = m:section(TypedSection, "network", "")
s.anonymous = true

e = s:option(Flag, "enable", translate("Bring up on boot"))

u = s:option(Value, "username",  translate("Username"))
u.default = ""
p = s:option(Value, "password",  translate("Password"))
p.default = ""
p.password = true

dev = s:option(ListValue, "ifname", translate("Interface"))
dev.default = "eth0"
for _,v in luci.util.vspairs(luci.sys.net.devices()) do
	if v:match("^eth%d") then
		dev:value(v)
	end
end

function m.on_save(self)
	uci:commit(userconf)
end

function m.on_after_commit(self)
	io.popen('/etc/init.d/sysuh3c restart')
end

return m
